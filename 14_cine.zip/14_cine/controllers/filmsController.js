const connection = require('../config/db');
class FilmsController {
  createfilm = (req, res) => {
    const { director_id } = req.params;
    const { title, release_year } = req.body;

    let sql =
      'Insert into film (id_director, title, release_year) values (?, ?, ?)';
    let values = [director_id, title, release_year];

    if (req.file) {
      sql =
        'Insert into film (id_director, title, release_year, film_img) values (?, ?, ?, ?)';
      values = [director_id, title, release_year, req.file.filename];
    }

    connection.query(sql, values, (err, result) => {
      if (err) {
        throw err;
      } else {
        res.redirect(`/director/profile/${director_id}`);
      }
    });
  };
}
module.exports = new FilmsController();
