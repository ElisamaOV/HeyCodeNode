var express = require('express');
const filmsController = require('../controllers/filmsController');
const uploadFile = require('../middleware/uploadFile');
var router = express.Router();

router.post(
  '/createFilm/:director_id',
  uploadFile('films'),
  filmsController.createfilm
);

module.exports = router;
